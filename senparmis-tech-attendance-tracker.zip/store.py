"""
Attendance data access on top of SQLite. Replaces the old Excel-backed excel_store.

``load_data()`` returns the same shape the pages already use:
    {subject: {"students": [{"row", "name"}], "dates": [{"col", "date", "topic"}],
               "cells": {(row, col): code}}}
where ``row`` is an enrollment id and ``col`` is a class-session id.

Terms: every section has one OPEN term (e.g. "1st Sem - Prelim") that new dates and graded items go into.
``load_data()`` and ``load_grades()`` show that open term unless another term is asked for. Locking a term
makes it read-only and opens the next one (see lock_period / unlock_period below).
"""
import os
import re
import sqlite3
import threading
import time
from datetime import date, datetime

from flask import g, has_request_context, url_for
from werkzeug.security import check_password_hash, generate_password_hash

import db
from config import (BACKUP_DIR, BACKUP_EVERY_MIN, BACKUP_KEEP, DB_FILE,
                    DEFAULT_SECTION, MIN_PASSWORD, SAMPLE_STUDENTS,
                    SAMPLE_SUBJECTS, SUBJECT_IMG_DIR, XLSX)
from helpers import clean_name, clean_sheet_name, norm_code, safe_text, who_is_it

write_lock = threading.RLock()
_init_lock = threading.Lock()


class FileLocked(Exception):
    """The database is busy (another program is writing to it)."""


def key_of(name):
    return clean_name(name).casefold()


# ------------------------------------------------------------------ set-up
def _current_teacher_filter():
    """Return (teacher_id, is_admin, monitor_section_id) from Flask request context.

    - Admin:   teacher_id=X, is_admin=True,  monitor_section_id=None  → sees everything
    - Teacher: teacher_id=X, is_admin=False, monitor_section_id=None  → sees assigned subjects
    - Monitor: teacher_id=X, is_admin=False, monitor_section_id=Y     → sees only that section
    """
    if has_request_context():
        tid = getattr(g, "teacher_id", None)
        is_adm = getattr(g, "is_admin", True)
        mon_sec = getattr(g, "monitor_section_id", None)
        # Preview-as-monitor: admin can toggle a session flag to preview a monitor's view
        preview_sec = getattr(g, "preview_section_id", None)
        if preview_sec is not None:
            return tid, False, preview_sec
        return tid, bool(is_adm), mon_sec
    return None, True, None


def _insert_subject(conn, name, teacher_id=None, section_name=None):
    pos = conn.execute("SELECT COALESCE(MAX(position), 0) + 1 FROM subjects").fetchone()[0]
    sid = conn.execute("INSERT INTO subjects (name, position, teacher_id) VALUES (?, ?, ?)",
                       (name, pos, teacher_id)).lastrowid
    sec_label = clean_name(section_name or DEFAULT_SECTION) or DEFAULT_SECTION
    sec = conn.execute("INSERT INTO sections (subject_id, name) VALUES (?, ?)", (sid, sec_label)).lastrowid
    _open_period(conn, sec)
    return sec


def _student_id(conn, name):
    """Find a student by name (case-insensitive) or create them."""
    k = key_of(name)
    row = conn.execute("SELECT id FROM students WHERE name_key = ?", (k,)).fetchone()
    if row:
        return row["id"]
    return conn.execute("INSERT INTO students (name, name_key) VALUES (?, ?)", (clean_name(name), k)).lastrowid


def _enroll(conn, student_id, section_id):
    """Enroll a student; returns the enrollment id, or None if they were already enrolled."""
    cur = conn.execute("INSERT OR IGNORE INTO enrollments (student_id, section_id) VALUES (?, ?)",
                       (student_id, section_id))
    return cur.lastrowid if cur.rowcount else None


def import_data(conn, data):
    """Load {subject: {students, dates, cells}} (as read from Excel) into an empty database."""
    for subject, sd in data.items():
        section = _insert_subject(conn, subject)
        enr = {}
        for s in sd["students"]:
            eid = _enroll(conn, _student_id(conn, s["name"]), section)
            if eid:
                enr[s["row"]] = eid
        for dd in sd["dates"]:
            iso = dd["date"].isoformat()
            if conn.execute("SELECT 1 FROM sessions WHERE section_id = ? AND date = ?", (section, iso)).fetchone():
                continue
            sess = _insert_session(conn, section, iso, dd["topic"] or None)
            for row, eid in enr.items():
                code = sd["cells"].get((row, dd["col"]))
                if code:
                    conn.execute("INSERT INTO attendance (enrollment_id, session_id, code) VALUES (?, ?, ?)",
                                 (eid, sess, code))


def _seed_samples(conn):
    for subject in SAMPLE_SUBJECTS:
        section = _insert_subject(conn, subject)
        for name in SAMPLE_STUDENTS:
            _enroll(conn, _student_id(conn, name), section)


def ensure_db():
    """Create the database on first run. If an old Excel workbook exists, import it (it is never changed)."""
    if os.path.exists(DB_FILE):
        conn = db.connect()
        try:
            db.migrate(conn)
        finally:
            conn.close()
        return
    with _init_lock:
        if os.path.exists(DB_FILE):
            return
        tmp = DB_FILE + ".new"
        if os.path.exists(tmp):
            os.remove(tmp)
        conn = db.connect(tmp)
        try:
            db.migrate(conn)
            if os.path.exists(XLSX):
                from excel_io import read_workbook
                import_data(conn, read_workbook(XLSX))
            else:
                _seed_samples(conn)
            conn.commit()
        finally:
            conn.close()
        os.replace(tmp, DB_FILE)


class _Tx:
    def __init__(self):
        ensure_db()
        self.conn = db.connect()

    def __enter__(self):
        return self.conn

    def __exit__(self, exc_type, exc, tb):
        try:
            if exc_type is None:
                self.conn.commit()
            else:
                self.conn.rollback()
        finally:
            self.conn.close()
        if exc_type is sqlite3.OperationalError and "locked" in str(exc).lower():
            raise FileLocked() from exc
        return False


# ------------------------------------------------------------------ terms
DEFAULT_SEMESTER, DEFAULT_TERM = "1st Sem", "Prelim"
TERM_NAMES = ("Prelim", "Midterm", "Pre-final", "Final")
SEMESTER_NAMES = ("1st Sem", "2nd Sem", "Summer")


def _period_dict(p):
    return {"id": p["id"], "semester": p["semester"], "term": p["term"],
            "label": f"{p['semester']} · {p['term']}", "locked": bool(p["locked"]),
            "locked_at": p["locked_at"] or "", "locked_by": p["locked_by"] or ""}


def _term_name(p):
    return f"{p['semester']} {p['term']}"


def _open_period(conn, sec_id):
    """The one term of a section that is still open for new dates and graded items (created if missing)."""
    row = conn.execute("SELECT * FROM periods WHERE section_id = ? AND locked = 0 "
                       "ORDER BY position DESC, id DESC LIMIT 1", (sec_id,)).fetchone()
    if row:
        return row
    pos = conn.execute("SELECT COALESCE(MAX(position), 0) + 1 FROM periods WHERE section_id = ?",
                       (sec_id,)).fetchone()[0]
    pid = conn.execute("INSERT INTO periods (section_id, semester, term, position) VALUES (?, ?, ?, ?)",
                       (sec_id, DEFAULT_SEMESTER, DEFAULT_TERM, pos)).lastrowid
    return conn.execute("SELECT * FROM periods WHERE id = ?", (pid,)).fetchone()


def _get_period(conn, sec_id, period_id=None):
    """A term of this section by id, or its open term when no id is given."""
    if period_id in (None, ""):
        return _open_period(conn, sec_id)
    try:
        pid = int(period_id)
    except (TypeError, ValueError):
        raise ValueError("That term was not found for this subject.")
    row = conn.execute("SELECT * FROM periods WHERE id = ? AND section_id = ?", (pid, sec_id)).fetchone()
    if not row:
        raise ValueError("That term was not found for this subject.")
    return row


def _period_row(conn, period_id):
    if period_id is None:
        return None
    return conn.execute("SELECT * FROM periods WHERE id = ?", (period_id,)).fetchone()


def _check_open(p):
    """Stop any change to a locked term."""
    if p is not None and p["locked"]:
        raise ValueError(f"{_term_name(p)} is locked, so its attendance and grades can't be changed. "
                         "Ask an admin to reopen it.")


def _period_counts(conn, period_id):
    dates = conn.execute("SELECT COUNT(*) FROM sessions WHERE period_id = ?", (period_id,)).fetchone()[0]
    items = conn.execute("SELECT COUNT(*) FROM grade_items WHERE period_id = ?", (period_id,)).fetchone()[0]
    return dates, items


def _insert_session(conn, sec_id, iso, topic, period_id=None):
    pid = period_id or _open_period(conn, sec_id)["id"]
    return conn.execute("INSERT INTO sessions (section_id, date, topic, period_id) VALUES (?, ?, ?, ?)",
                        (sec_id, iso, topic, pid)).lastrowid


def _clean_label(s, what):
    v = safe_text(s)[:40]
    if not v:
        raise ValueError(f"Enter the {what} name.")
    return v


def suggest_next_period(semester, term):
    """A sensible guess for the term after this one (Prelim, Midterm, Pre-final, Final, then the next semester)."""
    terms = [t.casefold() for t in TERM_NAMES]
    t = clean_name(term).casefold()
    if t not in terms:
        return clean_name(semester), ""
    i = terms.index(t)
    if i + 1 < len(TERM_NAMES):
        return clean_name(semester), TERM_NAMES[i + 1]
    sems = [s.casefold() for s in SEMESTER_NAMES]
    s = clean_name(semester).casefold()
    if s in sems and sems.index(s) + 1 < len(SEMESTER_NAMES):
        return SEMESTER_NAMES[sems.index(s) + 1], TERM_NAMES[0]
    return "", TERM_NAMES[0]


def list_periods(subject, section=None):
    """All terms of a section, oldest first, with what is recorded in each."""
    with _Tx() as conn:
        sec = _section_of(conn, subject, section)
        _open_period(conn, sec)
        rows = conn.execute("SELECT * FROM periods WHERE section_id = ? ORDER BY position, id", (sec,)).fetchall()
        out = []
        for r in rows:
            d = _period_dict(r)
            d["n_dates"], d["n_items"] = _period_counts(conn, r["id"])
            out.append(d)
        open_p = next((p for p in reversed(out) if not p["locked"]), None)
        last_locked = next((p for p in reversed(out) if p["locked"]), None)
        for p in out:
            p["is_open"] = not p["locked"]
            p["can_reopen"] = bool(last_locked and p["id"] == last_locked["id"] and open_p
                                   and not open_p["n_dates"] and not open_p["n_items"])
        return out


def update_period(subject, section, semester, term, period_id=None):
    """Rename the current (or specified) term's semester and term label without locking it."""
    sem, trm = _clean_label(semester, "semester"), _clean_label(term, "term")
    ensure_db()

    def run(conn):
        sec = _section_of(conn, subject, section)
        p = _get_period(conn, sec, period_id)
        # collision check: same (sem, trm) already used by a *different* term
        used = {(r["semester"].casefold(), r["term"].casefold())
                for r in conn.execute(
                    "SELECT semester, term FROM periods WHERE section_id = ? AND id != ?",
                    (sec, p["id"]))}
        if (sem.casefold(), trm.casefold()) in used:
            raise ValueError(f"'{sem} · {trm}' is already used by another term of this subject.")
        conn.execute("UPDATE periods SET semester = ?, term = ? WHERE id = ?",
                     (sem, trm, p["id"]))
        return _period_dict(conn.execute("SELECT * FROM periods WHERE id = ?", (p["id"],)).fetchone())
    return mutate(run)


def lock_period(subject, section, semester, term, next_semester, next_term):
    """Lock the section's open term (read-only from now on) and open a fresh, empty next term."""
    sem, trm = _clean_label(semester, "semester"), _clean_label(term, "term")
    nsem, ntrm = _clean_label(next_semester, "next semester"), _clean_label(next_term, "next term")
    if (sem.casefold(), trm.casefold()) == (nsem.casefold(), ntrm.casefold()):
        raise ValueError("The next term needs a different name from the one you are locking.")
    ensure_db()
    backup_workbook("before_lock_term", min_gap_min=0)

    def run(conn):
        sec = _section_of(conn, subject, section)
        cur = _open_period(conn, sec)
        n_dates, n_items = _period_counts(conn, cur["id"])
        if not n_dates and not n_items:
            raise ValueError("Nothing has been recorded in this term yet, so there is nothing to lock.")
        used = {(r["semester"].casefold(), r["term"].casefold()) for r in conn.execute(
            "SELECT semester, term FROM periods WHERE section_id = ? AND id != ?", (sec, cur["id"]))}
        if (sem.casefold(), trm.casefold()) in used:
            raise ValueError(f"'{sem} · {trm}' is already used by another term of this subject.")
        if (nsem.casefold(), ntrm.casefold()) in used:
            raise ValueError(f"'{nsem} · {ntrm}' is already used by an earlier term. Choose a new name for the next term.")
        w = conn.execute("SELECT exam_weight, quiz_weight, activity_weight FROM sections WHERE id = ?",
                         (sec,)).fetchone()
        conn.execute("UPDATE periods SET semester = ?, term = ?, locked = 1, locked_at = datetime('now', 'localtime'), "
                     "locked_by = ?, w_exam = ?, w_quiz = ?, w_activity = ? WHERE id = ?",
                     (sem, trm, who_is_it(), w["exam_weight"], w["quiz_weight"], w["activity_weight"], cur["id"]))
        pos = conn.execute("SELECT COALESCE(MAX(position), 0) + 1 FROM periods WHERE section_id = ?",
                           (sec,)).fetchone()[0]
        conn.execute("INSERT INTO periods (section_id, semester, term, position) VALUES (?, ?, ?, ?)",
                     (sec, nsem, ntrm, pos))
        return {"locked": f"{sem} · {trm}", "next": f"{nsem} · {ntrm}", "locked_id": cur["id"],
                "n_dates": n_dates, "n_items": n_items}
    return mutate(run)


def unlock_period(subject, section, period_id):
    """Admin only: reopen the most recent locked term, as long as the term after it is still empty."""
    def run(conn):
        _tid, is_adm, _mon = _current_teacher_filter()
        if not is_adm:
            raise ValueError("Only an admin can reopen a locked term.")
        sec = _section_of(conn, subject, section)
        p = _get_period(conn, sec, period_id)
        if not p["locked"]:
            raise ValueError("That term is not locked.")
        later = conn.execute("SELECT * FROM periods WHERE section_id = ? AND position > ? ORDER BY position",
                             (sec, p["position"])).fetchall()
        if any(l["locked"] for l in later):
            raise ValueError("Only the most recent locked term can be reopened.")
        for l in later:
            if any(_period_counts(conn, l["id"])):
                raise ValueError(f"{_term_name(l)} already has records, so {_term_name(p)} can't be reopened. "
                                 "A locked term can be reopened only while the term after it is still empty.")
        for l in later:
            conn.execute("DELETE FROM periods WHERE id = ?", (l["id"],))
        conn.execute("UPDATE periods SET locked = 0, locked_at = NULL, locked_by = NULL, "
                     "w_exam = NULL, w_quiz = NULL, w_activity = NULL WHERE id = ?", (p["id"],))
        return _period_dict(p)
    return mutate(run)


def _locked_labels(conn, enrollment_id):
    """Names of locked terms in which this student already has attendance or scores."""
    rows = conn.execute(
        "SELECT p.semester, p.term FROM periods p WHERE p.locked = 1 AND ("
        " EXISTS (SELECT 1 FROM attendance a JOIN sessions s ON s.id = a.session_id "
        "         WHERE a.enrollment_id = ? AND s.period_id = p.id)"
        " OR EXISTS (SELECT 1 FROM grades g JOIN grade_items gi ON gi.id = g.grade_item_id "
        "            WHERE g.enrollment_id = ? AND gi.period_id = p.id)) ORDER BY p.position",
        (enrollment_id, enrollment_id)).fetchall()
    return [_term_name(r) for r in rows]


def _has_locked_terms(conn, where, arg):
    return conn.execute(f"SELECT 1 FROM periods p {where} AND p.locked = 1 LIMIT 1", (arg,)).fetchone() is not None


# ------------------------------------------------------------ reading data
def _section_of(conn, subject, section=None):
    tid, is_adm, mon_sec = _current_teacher_filter()
    srow = conn.execute("SELECT id, teacher_id FROM subjects WHERE name = ?", (subject,)).fetchone()
    if not srow:
        raise ValueError("That subject was not found.")
    if not is_adm and tid is not None and mon_sec is None and srow["teacher_id"] != tid:
        raise ValueError("You do not have permission to modify that subject.")
    sec_name = clean_name(section or "")
    if sec_name:
        row = conn.execute("SELECT id FROM sections WHERE subject_id = ? AND name = ? COLLATE NOCASE",
                           (srow["id"], sec_name)).fetchone()
        if not row:
            raise ValueError("That section was not found in this subject.")
        # Monitor: enforce their section only
        if mon_sec is not None and row["id"] != mon_sec:
            raise ValueError("You do not have permission to access that section.")
        return row["id"]
    # No explicit section — monitors get routed to their section automatically
    if mon_sec is not None:
        # Verify this monitor's section belongs to this subject
        row = conn.execute("SELECT id FROM sections WHERE id = ? AND subject_id = ?",
                           (mon_sec, srow["id"])).fetchone()
        if not row:
            raise ValueError("You do not have permission to access that subject.")
        return row["id"]
    row = conn.execute("SELECT id FROM sections WHERE subject_id = ? ORDER BY id LIMIT 1",
                       (srow["id"],)).fetchone()
    if not row:
        raise ValueError("That subject has no sections.")
    return row["id"]


def _students_of(conn, sec, sec_name):
    return [{
        "row": r["id"],
        "student_id": r["student_id"],
        "name": r["name"],
        "section": sec_name,
        "student_no": r["student_no"] or "",
        "guardian_name": r["guardian_name"] or "",
        "guardian_phone": r["guardian_phone"] or "",
        "email": r["email"] or "",
        "address": r["address"] or "",
    } for r in conn.execute(
        "SELECT e.id, e.student_id, st.name, st.student_no, st.guardian_name, "
        "st.guardian_phone, st.email, st.address "
        "FROM enrollments e JOIN students st ON st.id = e.student_id "
        "WHERE e.section_id = ? ORDER BY e.id", (sec,))]


def _dates_cells(conn, sec, period_id):
    dates = [{"col": r["id"], "date": date.fromisoformat(r["date"]), "topic": r["topic"] or ""}
             for r in conn.execute("SELECT id, date, topic FROM sessions WHERE section_id = ? AND period_id = ? "
                                   "ORDER BY date", (sec, period_id))]
    cells = {(r["enrollment_id"], r["session_id"]): r["code"] for r in conn.execute(
        "SELECT a.enrollment_id, a.session_id, a.code FROM attendance a "
        "JOIN sessions se ON se.id = a.session_id WHERE se.section_id = ? AND se.period_id = ?",
        (sec, period_id))}
    return dates, cells


def load_data(teacher_id=None, is_admin=None, include_archived=False):
    """Every subject's students and attendance for its OPEN term."""
    if teacher_id is None and is_admin is None:
        teacher_id, is_admin, monitor_section_id = _current_teacher_filter()
    else:
        _, _, monitor_section_id = _current_teacher_filter()
    arch_clause = "" if include_archived else "AND (s.archived IS NULL OR s.archived = 0) "
    with _Tx() as conn:
        out = {}
        if not is_admin and teacher_id is not None and monitor_section_id is None:
            subjects = conn.execute(
                f"SELECT s.id, s.name, s.archived FROM subjects s WHERE s.teacher_id = ? {arch_clause}ORDER BY s.position, s.id",
                (teacher_id,)).fetchall()
        elif monitor_section_id is not None:
            # Monitor: show only the subject that contains their section
            subjects = conn.execute(
                f"SELECT s.id, s.name, s.archived FROM subjects s "
                f"JOIN sections sec ON sec.subject_id = s.id "
                f"WHERE sec.id = ? {arch_clause}ORDER BY s.position, s.id",
                (monitor_section_id,)).fetchall()
        else:
            where = "" if include_archived else "WHERE (s.archived IS NULL OR s.archived = 0) "
            subjects = conn.execute(
                f"SELECT s.id, s.name, s.archived FROM subjects s {where}ORDER BY s.position, s.id").fetchall()
        for sub in subjects:
            if monitor_section_id is not None:
                secs = conn.execute(
                    "SELECT id, name FROM sections WHERE id = ?", (monitor_section_id,)).fetchall()
            else:
                secs = conn.execute(
                    "SELECT id, name FROM sections WHERE subject_id = ? ORDER BY id", (sub["id"],)).fetchall()
            if not secs:
                continue
            sections_map = {}
            section_names = []
            is_sub_arch = bool(sub["archived"]) if "archived" in sub.keys() else False
            for sec_row in secs:
                sec = sec_row["id"]
                sec_name = sec_row["name"]
                section_names.append(sec_name)
                period = _open_period(conn, sec)
                dates, cells = _dates_cells(conn, sec, period["id"])
                sections_map[sec_name] = {
                    "section": sec_name,
                    "students": _students_of(conn, sec, sec_name),
                    "dates": dates,
                    "cells": cells,
                    "period": _period_dict(period),
                    "section_names": section_names,
                    "sections": sections_map,
                    "archived": is_sub_arch,
                }
            first_sec = sections_map[section_names[0]]
            out[sub["name"]] = dict(first_sec)
        return out


def load_period_data(subject, section=None, period_id=None):
    """One section's students and attendance for a chosen term (the open term when period_id is None)."""
    with _Tx() as conn:
        sec = _section_of(conn, subject, section)
        name = conn.execute("SELECT name FROM sections WHERE id = ?", (sec,)).fetchone()["name"]
        p = _get_period(conn, sec, period_id)
        dates, cells = _dates_cells(conn, sec, p["id"])
        return {"section": name, "students": _students_of(conn, sec, name), "dates": dates,
                "cells": cells, "period": _period_dict(p)}


def student_stats(sd):
    out = []
    for s in sd["students"]:
        counts = {"p": 0, "x": 0, "l": 0, "e": 0, "r": 0}
        for dd in sd["dates"]:
            code = sd["cells"].get((s["row"], dd["col"]), "")
            if code and code in counts:
                counts[code] += 1
        total = sum(counts.values())
        rate = (counts["p"] + counts["r"] + counts["l"]) / total if total else None
        out.append({**s, **counts, "total": total, "rate": rate})
    return out


# ------------------------------------------------------------ backups
def backup_workbook(tag, min_gap_min=0):
    """Save a timestamped copy of the database in the backups folder. Never blocks the action."""
    try:
        if not os.path.exists(DB_FILE):
            return
        os.makedirs(BACKUP_DIR, exist_ok=True)
        prefix = f"attendance_{tag}_"
        mine = sorted(f for f in os.listdir(BACKUP_DIR) if f.startswith(prefix) and f.endswith(".db"))
        if min_gap_min and mine:
            if time.time() - os.path.getmtime(os.path.join(BACKUP_DIR, mine[-1])) < min_gap_min * 60:
                return
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        _copy_db(os.path.join(BACKUP_DIR, f"{prefix}{stamp}.db"))
        mine = sorted(f for f in os.listdir(BACKUP_DIR) if f.startswith(prefix) and f.endswith(".db"))
        for old in mine[:-BACKUP_KEEP.get(tag, 30)]:
            os.remove(os.path.join(BACKUP_DIR, old))
    except (OSError, sqlite3.Error):
        pass


def backup_latest():
    """Keep one always-up-to-date copy (attendance_LATEST.db) next to the history copies."""
    try:
        os.makedirs(BACKUP_DIR, exist_ok=True)
        _copy_db(os.path.join(BACKUP_DIR, "attendance_LATEST.db"))
    except (OSError, sqlite3.Error):
        pass


def _copy_db(target):
    src = sqlite3.connect(DB_FILE)
    dst = sqlite3.connect(target)
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()


def list_backups():
    """Return all timestamped .db snapshots in the backups folder, newest first."""
    out = []
    if not os.path.exists(BACKUP_DIR):
        return out
    labels = {
        "auto": "Automatic snapshot",
        "before_delete_date": "Before deleting a date",
        "before_delete_subject": "Before deleting a subject",
        "before_delete_section": "Before deleting a section",
        "before_restore": "Before a restore",
        "before_lock_term": "Before locking a term",
    }
    try:
        files = [f for f in os.listdir(BACKUP_DIR) if f.endswith(".db") and f != "attendance_LATEST.db"]
    except OSError:
        return out
    for fn in files:
        full = os.path.join(BACKUP_DIR, fn)
        try:
            st = os.stat(full)
        except OSError:
            continue
        m = re.match(r"^attendance_(.+)_(\d{8}_\d{6})\.db$", fn)
        tag = m.group(1) if m else "snapshot"
        dt = datetime.fromtimestamp(st.st_mtime)
        subjects = []
        try:
            conn = sqlite3.connect(full)
            subjects = [r[0] for r in conn.execute("SELECT name FROM subjects ORDER BY position, id").fetchall()]
            conn.close()
        except sqlite3.Error:
            pass
        out.append({
            "filename": fn,
            "kind": labels.get(tag, tag.replace("_", " ").capitalize()),
            "when": dt.strftime("%b %d, %Y %I:%M:%S %p").replace(" 0", " "),
            "mtime": st.st_mtime,
            "subjects": subjects,
        })
    out.sort(key=lambda x: x["mtime"], reverse=True)
    return out


def restore_backup(filename):
    """Restore a snapshot from the backups folder (saves a safety backup of the current database first)."""
    safe_fn = os.path.basename(filename or "")
    if not safe_fn.endswith(".db") or safe_fn == "attendance_LATEST.db":
        raise ValueError("Invalid backup file.")
    src_path = os.path.join(BACKUP_DIR, safe_fn)
    if not os.path.isfile(src_path):
        raise ValueError("That backup file was not found.")
    with write_lock:
        backup_workbook("before_restore", min_gap_min=0)
        src = sqlite3.connect(src_path)
        dst = sqlite3.connect(DB_FILE)
        try:
            src.backup(dst)
        finally:
            dst.close()
            src.close()
        conn = db.connect()
        try:
            db.migrate(conn)
        finally:
            conn.close()
        backup_latest()


def reimport_from_excel():
    """Import subjects/students/marks from attendance_records.xlsx if missing in the database."""
    if not os.path.isfile(XLSX):
        raise ValueError("No attendance_records.xlsx file was found on the server.")
    from excel_io import read_workbook
    excel_data = read_workbook(XLSX)

    def run(conn):
        restored = []
        for subject, sd in excel_data.items():
            if conn.execute("SELECT 1 FROM subjects WHERE name = ?", (subject,)).fetchone():
                continue
            section = _insert_subject(conn, subject)
            enr = {}
            for s in sd["students"]:
                eid = _enroll(conn, _student_id(conn, s["name"]), section)
                if eid:
                    enr[s["row"]] = eid
            for dd in sd["dates"]:
                iso = dd["date"].isoformat()
                sess = _insert_session(conn, section, iso, dd["topic"] or None)
                for row, eid in enr.items():
                    code = sd["cells"].get((row, dd["col"]))
                    if code:
                        conn.execute("INSERT INTO attendance (enrollment_id, session_id, code) VALUES (?, ?, ?)",
                                     (eid, sess, code))
            restored.append(subject)
        return restored
    with write_lock:
        backup_workbook("before_restore", min_gap_min=0)
    return mutate(run)


def mutate(fn):
    """Run ``fn(conn)`` as one all-or-nothing change, with backups around it."""
    ensure_db()
    with write_lock:
        backup_workbook("auto", BACKUP_EVERY_MIN)
        with _Tx() as conn:
            result = fn(conn)
        backup_latest()
        return result


# ------------------------------------------------------------ writing data
def apply_marks(subject, d, topic, items, new_names=(), section=None):
    def run(conn):
        if is_subject_archived(subject):
            raise ValueError(f"Subject '{subject}' is archived. Unarchive it first to record attendance.")
        sec = _section_of(conn, subject, section)
        iso = d.isoformat()
        row = conn.execute("SELECT id, period_id FROM sessions WHERE section_id = ? AND date = ?",
                           (sec, iso)).fetchone()
        created = row is None
        topic_clean = safe_text(topic) or None
        if created:
            sess = _insert_session(conn, sec, iso, topic_clean)
        else:
            _check_open(_period_row(conn, row["period_id"]))
            sess = row["id"]
            conn.execute("UPDATE sessions SET topic = ? WHERE id = ?", (topic_clean, sess))
        names = {}                                   # lowercase name -> enrollment id
        for r in conn.execute("SELECT e.id, st.name FROM enrollments e JOIN students st ON st.id = e.student_id "
                              "WHERE e.section_id = ?", (sec,)):
            names[key_of(r["name"])] = r["id"]
        added = []
        for n in new_names:                          # students added from a scanned sheet
            n = safe_text(n)
            if n and key_of(n) not in names:
                names[key_of(n)] = _enroll(conn, _student_id(conn, n), sec)
                added.append(n)
        saved, changes = 0, []
        for it in items:
            name = clean_name(str(it.get("name", "")))
            raw_code = it.get("code")
            code = norm_code(raw_code)
            clearing = (not code) and raw_code in ("", None) and bool(it.get("clear"))
            if not name or (not code and not clearing):
                continue
            eid = None
            rid = it.get("row")
            if isinstance(rid, int):                 # trust the row only if it is this student in this subject
                hit = conn.execute("SELECT st.name FROM enrollments e JOIN students st ON st.id = e.student_id "
                                   "WHERE e.id = ? AND e.section_id = ?", (rid, sec)).fetchone()
                if hit and key_of(hit["name"]) == key_of(name):
                    eid = rid
            if eid is None:
                eid = names.get(key_of(name))
            if not eid:
                continue
            old_row = conn.execute("SELECT code FROM attendance WHERE enrollment_id = ? AND session_id = ?",
                                   (eid, sess)).fetchone()
            old = old_row["code"] if old_row else ""
            if code:
                conn.execute("INSERT INTO attendance (enrollment_id, session_id, code) VALUES (?, ?, ?) "
                             "ON CONFLICT (enrollment_id, session_id) DO UPDATE SET code = excluded.code",
                             (eid, sess, code))
            else:
                conn.execute("DELETE FROM attendance WHERE enrollment_id = ? AND session_id = ?", (eid, sess))
            changes.append((name, old, code))
            saved += 1
        return {"saved": saved, "created": created, "changes": changes, "added": added}
    return mutate(run)


def delete_date(subject, d, section=None):
    """Remove one class date (topic and every mark) from a subject."""
    def run(conn):
        sec = _section_of(conn, subject, section)
        row = conn.execute("SELECT id, topic, period_id FROM sessions WHERE section_id = ? AND date = ?",
                           (sec, d.isoformat())).fetchone()
        if not row:
            raise ValueError("That date was not found.")
        _check_open(_period_row(conn, row["period_id"]))
        marks = conn.execute("SELECT COUNT(*) FROM attendance WHERE session_id = ?", (row["id"],)).fetchone()[0]
        conn.execute("DELETE FROM sessions WHERE id = ?", (row["id"],))
        return marks, clean_name(row["topic"] or "")
    return mutate(run)


def add_students(subjects, names, section=None):
    def run(conn):
        tid, is_adm, mon_sec = _current_teacher_filter()
        if mon_sec is not None:
            added, skipped = 0, []
            for n in names:
                if _enroll(conn, _student_id(conn, n), mon_sec):
                    added += 1
                else:
                    skipped.append(f"{n}")
            return added, skipped
        added, skipped = 0, []
        for sub in subjects:
            try:
                sec = _section_of(conn, sub, section) if section else _section_of(conn, sub)
            except ValueError:
                sec = _section_of(conn, sub)
            for n in names:
                if _enroll(conn, _student_id(conn, n), sec):
                    added += 1
                else:
                    skipped.append(f"{n} ({sub})")
        return added, skipped
    return mutate(run)


def _refuse_if_locked_records(conn, enrollment_id, name):
    labels = _locked_labels(conn, enrollment_id)
    if labels:
        raise ValueError(f"{name} has records in locked term(s): {', '.join(labels)}. Removing the student would "
                         "erase them, so keep them on the list (or ask an admin to reopen the term first).")


def remove_student(subject, row, name, everywhere, section=None):
    def run(conn):
        tid, is_adm, mon_sec = _current_teacher_filter()
        if everywhere:
            if mon_sec is not None:
                raise ValueError("Section monitors cannot remove students across all subjects.")
            if not is_adm and tid is not None:
                rows = conn.execute(
                    "SELECT e.id FROM enrollments e JOIN sections sec ON sec.id = e.section_id "
                    "JOIN subjects s ON s.id = sec.subject_id JOIN students st ON st.id = e.student_id "
                    "WHERE s.teacher_id = ? AND st.name_key = ?", (tid, key_of(name))).fetchall()
            else:
                rows = conn.execute(
                    "SELECT e.id FROM enrollments e JOIN students st ON st.id = e.student_id "
                    "WHERE st.name_key = ?", (key_of(name),)).fetchall()
            for r in rows:
                _refuse_if_locked_records(conn, r["id"], name)
            for r in rows:
                conn.execute("DELETE FROM enrollments WHERE id = ?", (r["id"],))
            conn.execute("DELETE FROM students WHERE id NOT IN (SELECT student_id FROM enrollments)")
            return len(rows)

        sec = _section_of(conn, subject, section)
        hit = None
        if isinstance(row, int):
            r = conn.execute("SELECT e.id, st.name FROM enrollments e JOIN students st ON st.id = e.student_id "
                             "WHERE e.id = ? AND e.section_id = ?", (row, sec)).fetchone()
            if r and key_of(r["name"]) == key_of(name):
                hit = r["id"]
        if hit is None:
            r = conn.execute("SELECT e.id FROM enrollments e JOIN students st ON st.id = e.student_id "
                             "WHERE e.section_id = ? AND st.name_key = ?", (sec, key_of(name))).fetchone()
            hit = r["id"] if r else None
        if hit:
            _refuse_if_locked_records(conn, hit, name)
            conn.execute("DELETE FROM enrollments WHERE id = ?", (hit,))
            conn.execute("DELETE FROM students WHERE id NOT IN (SELECT student_id FROM enrollments)")
            return 1
        return 0
    return mutate(run)


# -------------------------------------------------------- subject customization
def _img_stem(subject):
    return re.sub(r'[^a-zA-Z0-9_\-]', '_', clean_sheet_name(subject).lower())


def get_subject_image_file(subject):
    if not os.path.exists(SUBJECT_IMG_DIR):
        return None
    for ext in (".jpg", ".jpeg", ".png", ".webp", ".gif"):
        fn = f"{_img_stem(subject)}{ext}"
        if os.path.isfile(os.path.join(SUBJECT_IMG_DIR, fn)):
            return fn
    return None


def subject_image_url(subject):
    img = get_subject_image_file(subject)
    return url_for("subject_image", subject=subject) if img else None


def remove_subject_image(subject):
    if not os.path.exists(SUBJECT_IMG_DIR):
        return
    for ext in (".jpg", ".jpeg", ".png", ".webp", ".gif"):
        p = os.path.join(SUBJECT_IMG_DIR, f"{_img_stem(subject)}{ext}")
        if os.path.isfile(p):
            try:
                os.remove(p)
            except OSError:
                pass


def is_subject_archived(name):
    """Check if a subject is marked archived."""
    with _Tx() as conn:
        row = conn.execute("SELECT archived FROM subjects WHERE name = ?", (name,)).fetchone()
        return bool(row["archived"]) if row and "archived" in row.keys() else False


def list_archived_subjects():
    """List archived subjects accessible to the current user."""
    tid, is_adm, _mon = _current_teacher_filter()
    with _Tx() as conn:
        if not is_adm and tid is not None and _mon is None:
            rows = conn.execute(
                "SELECT s.id, s.name, s.archived_at, s.archive_note, "
                "(SELECT COUNT(DISTINCT e.student_id) FROM enrollments e "
                " JOIN sections sec ON sec.id = e.section_id WHERE sec.subject_id = s.id) AS n_students "
                "FROM subjects s WHERE s.teacher_id = ? AND s.archived = 1 ORDER BY s.name",
                (tid,)).fetchall()
        elif _mon is not None:
            rows = []
        else:
            rows = conn.execute(
                "SELECT s.id, s.name, s.archived_at, s.archive_note, "
                "(SELECT COUNT(DISTINCT e.student_id) FROM enrollments e "
                " JOIN sections sec ON sec.id = e.section_id WHERE sec.subject_id = s.id) AS n_students "
                "FROM subjects s WHERE s.archived = 1 ORDER BY s.name").fetchall()
        return [dict(r) for r in rows]


def archive_subject(name, note=""):
    """Archive a subject: marks it read-only and hides from active roll calls while keeping all records."""
    ensure_db()
    backup_workbook("before_archive_subject", min_gap_min=0)

    def run(conn):
        tid, is_adm, _mon = _current_teacher_filter()
        if _mon is not None:
            raise ValueError("Section monitors cannot archive subjects.")
        row = conn.execute("SELECT id, teacher_id FROM subjects WHERE name = ?", (name,)).fetchone()
        if not row:
            raise ValueError("That subject was not found.")
        if not is_adm and tid is not None and row["teacher_id"] != tid:
            raise ValueError("You do not have permission to archive that subject.")
        conn.execute("UPDATE subjects SET archived = 1, archived_at = ?, archive_note = ? WHERE id = ?",
                     (datetime.now().isoformat(), safe_text(note)[:200] if note else None, row["id"]))
    mutate(run)


def unarchive_subject(name):
    """Restore an archived subject back to active status."""
    ensure_db()

    def run(conn):
        tid, is_adm, _mon = _current_teacher_filter()
        if _mon is not None:
            raise ValueError("Section monitors cannot unarchive subjects.")
        row = conn.execute("SELECT id, teacher_id FROM subjects WHERE name = ?", (name,)).fetchone()
        if not row:
            raise ValueError("That subject was not found.")
        if not is_adm and tid is not None and row["teacher_id"] != tid:
            raise ValueError("You do not have permission to unarchive that subject.")
        conn.execute("UPDATE subjects SET archived = 0, archived_at = NULL, archive_note = NULL WHERE id = ?",
                     (row["id"],))
    mutate(run)


def delete_subject(name):
    ensure_db()
    backup_workbook("before_delete_subject", min_gap_min=0)

    def run(conn):
        tid, is_adm, _mon = _current_teacher_filter()
        if _mon is not None:
            raise ValueError("Section monitors cannot delete subjects.")
        row = conn.execute("SELECT id, teacher_id FROM subjects WHERE name = ?", (name,)).fetchone()
        if not row:
            raise ValueError("That subject was not found.")
        if not is_adm and tid is not None and row["teacher_id"] != tid:
            raise ValueError("You do not have permission to delete that subject.")
        if not is_adm and _has_locked_terms(
                conn, "JOIN sections sec ON sec.id = p.section_id WHERE sec.subject_id = ?", row["id"]):
            raise ValueError("This subject has locked terms, so only an admin can delete it.")
        conn.execute("DELETE FROM subjects WHERE id = ?", (row["id"],))
        conn.execute("DELETE FROM students WHERE id NOT IN (SELECT student_id FROM enrollments)")
    mutate(run)
    remove_subject_image(name)


def add_subject(name, copy_from, teacher_id=None, section_name=None):
    def run(conn):
        tid, is_adm, _mon = _current_teacher_filter()
        if _mon is not None:
            raise ValueError("Section monitors cannot create subjects.")
        owner = teacher_id if is_adm else (tid or teacher_id)
        if conn.execute("SELECT 1 FROM subjects WHERE name = ?", (name,)).fetchone():
            raise ValueError("A subject with that name already exists.")
        source = []
        if copy_from and conn.execute("SELECT 1 FROM subjects WHERE name = ?", (copy_from,)).fetchone():
            src = _section_of(conn, copy_from)
            source = [r["student_id"] for r in conn.execute(
                "SELECT student_id FROM enrollments WHERE section_id = ? ORDER BY id", (src,))]
        sec = _insert_subject(conn, name, owner, section_name=section_name)
        for sid in source:
            _enroll(conn, sid, sec)
        return len(source)
    return mutate(run)


def add_section(subject, section_name, copy_from_section=None):
    sec_label = clean_sheet_name(section_name)
    if not sec_label:
        raise ValueError("Please enter a valid section name (e.g. BSCS-1A).")

    def run(conn):
        tid, is_adm, _mon = _current_teacher_filter()
        if _mon is not None:
            raise ValueError("Section monitors cannot create sections.")
        srow = conn.execute("SELECT id, teacher_id FROM subjects WHERE name = ?", (subject,)).fetchone()
        if not srow:
            raise ValueError("That subject was not found.")
        if not is_adm and tid is not None and srow["teacher_id"] != tid:
            raise ValueError("You do not have permission to modify that subject.")
        if conn.execute("SELECT 1 FROM sections WHERE subject_id = ? AND name = ? COLLATE NOCASE",
                        (srow["id"], sec_label)).fetchone():
            raise ValueError(f"Section '{sec_label}' already exists in {subject}.")
        source = []
        if copy_from_section:
            src_row = conn.execute("SELECT id FROM sections WHERE subject_id = ? AND name = ? COLLATE NOCASE",
                                   (srow["id"], copy_from_section)).fetchone()
            if src_row:
                source = [r["student_id"] for r in conn.execute(
                    "SELECT student_id FROM enrollments WHERE section_id = ? ORDER BY id", (src_row["id"],))]
        new_sec = conn.execute("INSERT INTO sections (subject_id, name) VALUES (?, ?)",
                               (srow["id"], sec_label)).lastrowid
        _open_period(conn, new_sec)
        for sid in source:
            _enroll(conn, sid, new_sec)
        return len(source)
    return mutate(run)


def rename_section(subject, old_name, new_name):
    new_label = clean_sheet_name(new_name)
    if not new_label:
        raise ValueError("Please enter a valid section name.")

    def run(conn):
        tid, is_adm, _mon = _current_teacher_filter()
        if _mon is not None:
            raise ValueError("Section monitors cannot rename sections.")
        sec_id = _section_of(conn, subject, old_name)
        srow = conn.execute("SELECT subject_id FROM sections WHERE id = ?", (sec_id,)).fetchone()
        conflict = conn.execute(
            "SELECT id FROM sections WHERE subject_id = ? AND name = ? COLLATE NOCASE AND id != ?",
            (srow["subject_id"], new_label, sec_id)).fetchone()
        if conflict:
            raise ValueError(f"Section '{new_label}' already exists in {subject}.")
        conn.execute("UPDATE sections SET name = ? WHERE id = ?", (new_label, sec_id))
        return new_label
    return mutate(run)


def delete_section(subject, section_name):
    ensure_db()
    backup_workbook("before_delete_section", min_gap_min=0)

    def run(conn):
        _tid, is_adm, _mon = _current_teacher_filter()
        if _mon is not None:
            raise ValueError("Section monitors cannot delete sections.")
        sec_id = _section_of(conn, subject, section_name)
        srow = conn.execute("SELECT subject_id FROM sections WHERE id = ?", (sec_id,)).fetchone()
        count = conn.execute("SELECT COUNT(*) FROM sections WHERE subject_id = ?", (srow["subject_id"],)).fetchone()[0]
        if count <= 1:
            raise ValueError("Cannot delete the only section of a subject (rename it or delete the subject instead).")
        if not is_adm and _has_locked_terms(conn, "WHERE p.section_id = ?", sec_id):
            raise ValueError("This section has locked terms, so only an admin can delete it.")
        conn.execute("DELETE FROM sections WHERE id = ?", (sec_id,))
        conn.execute("DELETE FROM students WHERE id NOT IN (SELECT student_id FROM enrollments)")
    mutate(run)


# -------------------------------------------------------- teacher accounts
def list_teachers():
    with _Tx() as conn:
        rows = conn.execute(
            "SELECT t.id, t.username, t.display_name, t.is_admin, t.is_monitor, t.monitor_section_id, t.created_at, "
            "(SELECT COUNT(*) FROM subjects s WHERE s.teacher_id = t.id) AS n_subjects, "
            "sec.name AS monitor_section_name, sub.name AS monitor_subject_name "
            "FROM teachers t "
            "LEFT JOIN sections sec ON sec.id = t.monitor_section_id "
            "LEFT JOIN subjects sub ON sub.id = sec.subject_id "
            "ORDER BY t.is_admin DESC, t.display_name, t.username").fetchall()
        return [dict(r) for r in rows]


def get_teacher(teacher_id):
    with _Tx() as conn:
        row = conn.execute(
            "SELECT id, username, display_name, password_hash, is_admin, is_monitor, monitor_section_id "
            "FROM teachers WHERE id = ?",
            (teacher_id,)).fetchone()
        return dict(row) if row else None


def verify_teacher(username_or_pw, password=None):
    """Verify a teacher by (username, password), or if username is blank, check password against all teachers."""
    with _Tx() as conn:
        cols = "id, username, display_name, password_hash, is_admin, is_monitor, monitor_section_id"
        if password is not None and username_or_pw:
            row = conn.execute(f"SELECT {cols} FROM teachers WHERE username = ?",
                               (username_or_pw.strip(),)).fetchone()
            if row and check_password_hash(row["password_hash"], password):
                return dict(row)
            return None
        pw = password if password is not None else username_or_pw
        for row in conn.execute(f"SELECT {cols} FROM teachers"):
            if check_password_hash(row["password_hash"], pw):
                return dict(row)
        return None


def list_all_sections():
    """Return all sections with their subject name, for the section-monitor dropdown."""
    with _Tx() as conn:
        rows = conn.execute(
            "SELECT sec.id, sec.name AS section_name, sub.name AS subject_name "
            "FROM sections sec JOIN subjects sub ON sub.id = sec.subject_id "
            "ORDER BY sub.position, sub.id, sec.id").fetchall()
        return [dict(r) for r in rows]


def create_teacher(username, display_name, password, is_admin=False, monitor_section_id=None):
    uname = re.sub(r"[^a-zA-Z0-9_.\-]", "", (username or "").strip()).lower()
    dname = clean_name(display_name or uname)
    if not uname or len(uname) < 2:
        raise ValueError("Username must be at least 2 characters (letters, numbers, _, ., -).")
    if not password or len(password) < MIN_PASSWORD:
        raise ValueError(f"Password must be at least {MIN_PASSWORD} characters.")
    pw_hash = generate_password_hash(password)
    mon_sec = int(monitor_section_id) if monitor_section_id else None
    is_mon = 1 if mon_sec else 0

    def run(conn):
        if conn.execute("SELECT 1 FROM teachers WHERE username = ?", (uname,)).fetchone():
            raise ValueError("That username is already taken.")
        if mon_sec and not conn.execute("SELECT 1 FROM sections WHERE id = ?", (mon_sec,)).fetchone():
            raise ValueError("That section was not found.")
        return conn.execute(
            "INSERT INTO teachers (username, display_name, password_hash, is_admin, is_monitor, monitor_section_id) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (uname, dname, pw_hash, 1 if is_admin else 0, is_mon, mon_sec)).lastrowid
    return mutate(run)


def update_teacher_password(teacher_id, new_password):
    if not new_password or len(new_password) < MIN_PASSWORD:
        raise ValueError(f"Password must be at least {MIN_PASSWORD} characters.")
    pw_hash = generate_password_hash(new_password)

    def run(conn):
        cur = conn.execute("UPDATE teachers SET password_hash = ? WHERE id = ?", (pw_hash, int(teacher_id)))
        if not cur.rowcount:
            raise ValueError("Teacher account not found.")
    mutate(run)


def delete_teacher(teacher_id):
    def run(conn):
        row = conn.execute("SELECT is_admin FROM teachers WHERE id = ?", (int(teacher_id),)).fetchone()
        if not row:
            raise ValueError("Teacher account not found.")
        if row["is_admin"]:
            admins = conn.execute("SELECT COUNT(*) FROM teachers WHERE is_admin = 1").fetchone()[0]
            if admins <= 1:
                raise ValueError("Cannot delete the last admin account.")
        conn.execute("DELETE FROM teachers WHERE id = ?", (int(teacher_id),))
    mutate(run)


def list_subjects_with_owners():
    with _Tx() as conn:
        rows = conn.execute(
            "SELECT s.id, s.name, s.teacher_id, t.username AS teacher_username, t.display_name AS teacher_name "
            "FROM subjects s LEFT JOIN teachers t ON t.id = s.teacher_id ORDER BY s.position, s.id").fetchall()
        return [dict(r) for r in rows]


def assign_subject_teacher(subject_name, teacher_id):
    def run(conn):
        tid = int(teacher_id) if teacher_id not in (None, "", "0", 0) else None
        if tid is not None and not conn.execute("SELECT 1 FROM teachers WHERE id = ?", (tid,)).fetchone():
            raise ValueError("Selected teacher does not exist.")
        cur = conn.execute("UPDATE subjects SET teacher_id = ? WHERE name = ?", (tid, subject_name))
        if not cur.rowcount:
            raise ValueError("Subject not found.")
    mutate(run)


# -------------------------------------------------------- student profiles
def update_student_profile(name, new_name=None, student_no="", guardian_name="",
                           guardian_phone="", email="", address=""):
    old_k = key_of(name)
    cleaned_new = safe_text(new_name or name) or clean_name(name)
    new_k = key_of(cleaned_new)
    s_no = safe_text(student_no)[:60]
    g_name = safe_text(guardian_name)[:120]
    g_phone = safe_text(guardian_phone)[:60]
    em = safe_text(email)[:120]
    addr = safe_text(address)[:240]

    def run(conn):
        row = conn.execute("SELECT id FROM students WHERE name_key = ?", (old_k,)).fetchone()
        if not row:
            raise ValueError("Student was not found.")
        if new_k != old_k and conn.execute("SELECT 1 FROM students WHERE name_key = ? AND id != ?",
                                           (new_k, row["id"])).fetchone():
            raise ValueError("Another student already has that name.")
        conn.execute(
            "UPDATE students SET name = ?, name_key = ?, student_no = ?, guardian_name = ?, "
            "guardian_phone = ?, email = ?, address = ? WHERE id = ?",
            (cleaned_new, new_k, s_no, g_name, g_phone, em, addr, row["id"]))
        return cleaned_new
    return mutate(run)


# --------------------------------------------------------------- grades
GRADE_CATEGORIES = ("exam", "quiz", "activity")
CATEGORY_LABELS = {"exam": "Exam", "quiz": "Quiz", "activity": "Activity"}


def pct_to_scale(pct):
    """Convert a 0-100 percentage to standard Philippine 1.00 - 5.00 college grade scale."""
    if pct is None:
        return None
    p = round(float(pct), 2)
    if p >= 96:
        return "1.00"
    if p >= 93:
        return "1.25"
    if p >= 90:
        return "1.50"
    if p >= 87:
        return "1.75"
    if p >= 84:
        return "2.00"
    if p >= 81:
        return "2.25"
    if p >= 78:
        return "2.50"
    if p >= 75:
        return "2.75"
    if p >= 70:
        return "3.00"
    return "5.00"


def load_grades(subject, section=None, period_id=None):
    """Gradebook for (subject, section) and one term (the open term when period_id is None):
    weights, lock state, items, student scores, and computed standing."""
    with _Tx() as conn:
        sec_id = _section_of(conn, subject, section)
        sec_row = conn.execute(
            "SELECT id, name, exam_weight, quiz_weight, activity_weight, weights_locked "
            "FROM sections WHERE id = ?", (sec_id,)).fetchone()
        period = _get_period(conn, sec_id, period_id)
        weights = {
            "exam": float(sec_row["exam_weight"]),
            "quiz": float(sec_row["quiz_weight"]),
            "activity": float(sec_row["activity_weight"]),
        }
        if period["locked"] and period["w_exam"] is not None:       # a locked term keeps its own weights
            weights = {"exam": float(period["w_exam"]), "quiz": float(period["w_quiz"]),
                       "activity": float(period["w_activity"])}
        locked = bool(sec_row["weights_locked"])
        items = [dict(r) for r in conn.execute(
            "SELECT id, category, title, max_score, date FROM grade_items "
            "WHERE section_id = ? AND period_id = ? "
            "ORDER BY CASE category WHEN 'exam' THEN 1 WHEN 'quiz' THEN 2 ELSE 3 END, id",
            (sec_id, period["id"])).fetchall()]
        for it in items:
            it["label"] = CATEGORY_LABELS.get(it["category"], it["category"].capitalize())
        students = [dict(r) for r in conn.execute(
            "SELECT e.id AS enrollment_id, st.name, st.student_no FROM enrollments e "
            "JOIN students st ON st.id = e.student_id WHERE e.section_id = ? ORDER BY e.id",
            (sec_id,)).fetchall()]
        scores = {}
        for r in conn.execute(
                "SELECT g.grade_item_id, g.enrollment_id, g.score FROM grades g "
                "JOIN grade_items gi ON gi.id = g.grade_item_id WHERE gi.section_id = ? AND gi.period_id = ?",
                (sec_id, period["id"])):
            scores[(r["enrollment_id"], r["grade_item_id"])] = float(r["score"])

        items_by_cat = {cat: [it for it in items if it["category"] == cat] for cat in GRADE_CATEGORIES}
        cat_max = {cat: sum(float(it["max_score"]) for it in items_by_cat[cat]) for cat in GRADE_CATEGORIES}

        rows = []
        for s in students:
            eid = s["enrollment_id"]
            cat_pct = {}
            cat_earned = {}
            for cat in GRADE_CATEGORIES:
                if cat_max[cat] > 0:
                    earned = sum(scores.get((eid, it["id"]), 0.0) for it in items_by_cat[cat])
                    cat_earned[cat] = earned
                    cat_pct[cat] = (earned / cat_max[cat]) * 100.0
                else:
                    cat_earned[cat] = None
                    cat_pct[cat] = None
            active_weight = sum(weights[c] for c in GRADE_CATEGORIES if cat_pct[c] is not None and weights[c] > 0)
            if active_weight > 0:
                final_pct = sum(cat_pct[c] * weights[c] for c in GRADE_CATEGORIES if cat_pct[c] is not None) / active_weight
            else:
                final_pct = None
            rows.append({
                "enrollment_id": eid,
                "name": s["name"],
                "student_no": s["student_no"] or "",
                "scores": {it["id"]: scores.get((eid, it["id"])) for it in items},
                "cat_earned": cat_earned,
                "cat_max": cat_max,
                "cat_pct": cat_pct,
                "final_pct": final_pct,
                "scale": pct_to_scale(final_pct),
                "passing": (final_pct >= 70.0) if final_pct is not None else None,
            })
        is_sub_arch = is_subject_archived(subject)
        return {
            "section": sec_row["name"],
            "weights": weights,
            "locked": locked or is_sub_arch,
            "period": _period_dict(period),
            "period_locked": bool(period["locked"]) or is_sub_arch,
            "archived": is_sub_arch,
            "items": items,
            "items_by_cat": items_by_cat,
            "cat_max": cat_max,
            "rows": rows,
        }


def save_grade_weights(subject, section, exam_w, quiz_w, activity_w):
    if is_subject_archived(subject):
        raise ValueError(f"Subject '{subject}' is archived and read-only.")
    try:
        ew, qw, aw = float(exam_w), float(quiz_w), float(activity_w)
    except (TypeError, ValueError):
        raise ValueError("Weights must be valid numbers.")
    if ew < 0 or qw < 0 or aw < 0 or abs((ew + qw + aw) - 100.0) > 0.05:
        raise ValueError("Exam, Quiz, and Activity weights must be non-negative and add up to 100%.")

    def run(conn):
        sec_id = _section_of(conn, subject, section)
        locked = conn.execute("SELECT weights_locked FROM sections WHERE id = ?", (sec_id,)).fetchone()["weights_locked"]
        if locked:
            raise ValueError("Grade weights are locked. Unlock them first before changing percentages.")
        conn.execute(
            "UPDATE sections SET exam_weight = ?, quiz_weight = ?, activity_weight = ? WHERE id = ?",
            (ew, qw, aw, sec_id))
    mutate(run)


def set_weights_lock(subject, section, locked):
    if is_subject_archived(subject):
        raise ValueError(f"Subject '{subject}' is archived and read-only.")
    def run(conn):
        sec_id = _section_of(conn, subject, section)
        conn.execute("UPDATE sections SET weights_locked = ? WHERE id = ?", (1 if locked else 0, sec_id))
    mutate(run)


def add_grade_item(subject, section, category, title, max_score, date_str=""):
    if is_subject_archived(subject):
        raise ValueError(f"Subject '{subject}' is archived and read-only.")
    cat = (category or "").strip().lower()
    if cat not in GRADE_CATEGORIES:
        raise ValueError("Choose Exam, Quiz, or Activity.")
    t = safe_text(title)[:80]
    if not t:
        raise ValueError("Enter a title (e.g. Quiz 1 or Midterm Exam).")
    try:
        mx = float(max_score)
    except (TypeError, ValueError):
        raise ValueError("Max score must be a number greater than 0.")
    if mx <= 0 or mx > 10000:
        raise ValueError("Max score must be between 1 and 10,000.")

    def run(conn):
        sec_id = _section_of(conn, subject, section)
        return conn.execute(
            "INSERT INTO grade_items (section_id, category, title, max_score, date, period_id) VALUES (?, ?, ?, ?, ?, ?)",
            (sec_id, cat, t, mx, safe_text(date_str)[:20], _open_period(conn, sec_id)["id"])).lastrowid
    return mutate(run)


def delete_grade_item(subject, section, item_id):
    if is_subject_archived(subject):
        raise ValueError(f"Subject '{subject}' is archived and read-only.")
    def run(conn):
        sec_id = _section_of(conn, subject, section)
        row = conn.execute("SELECT id, title, period_id FROM grade_items WHERE id = ? AND section_id = ?",
                           (int(item_id), sec_id)).fetchone()
        if not row:
            raise ValueError("Grade item not found.")
        _check_open(_period_row(conn, row["period_id"]))
        conn.execute("DELETE FROM grade_items WHERE id = ?", (row["id"],))
        return row["title"]
    return mutate(run)


def save_grade_scores(subject, section, entries):
    """Save [(enrollment_id, item_id, score_or_none), ...] for a section."""
    if is_subject_archived(subject):
        raise ValueError(f"Subject '{subject}' is archived and read-only.")
    def run(conn):
        sec_id = _section_of(conn, subject, section)
        valid_items, locked_items = {}, {}
        for r in conn.execute(
                "SELECT gi.id, gi.max_score, p.locked, p.semester, p.term FROM grade_items gi "
                "LEFT JOIN periods p ON p.id = gi.period_id WHERE gi.section_id = ?", (sec_id,)):
            valid_items[r["id"]] = float(r["max_score"])
            if r["locked"]:
                locked_items[r["id"]] = f"{r['semester']} {r['term']}"
        valid_enr = {r["id"] for r in conn.execute(
            "SELECT id FROM enrollments WHERE section_id = ?", (sec_id,))}
        saved = 0
        for eid, iid, val in entries:
            if eid not in valid_enr or iid not in valid_items:
                continue
            if iid in locked_items:
                raise ValueError(f"{locked_items[iid]} is locked, so its scores can't be changed. "
                                 "Ask an admin to reopen it.")
            if val is None or val == "":
                conn.execute("DELETE FROM grades WHERE grade_item_id = ? AND enrollment_id = ?", (iid, eid))
            else:
                sc = float(val)
                if sc < 0 or sc > valid_items[iid]:
                    raise ValueError(f"Score {sc:g} is outside 0 to {valid_items[iid]:g}.")
                conn.execute(
                    "INSERT INTO grades (grade_item_id, enrollment_id, score) VALUES (?, ?, ?) "
                    "ON CONFLICT (grade_item_id, enrollment_id) DO UPDATE SET score = excluded.score",
                    (iid, eid, sc))
                saved += 1
        return saved
    return mutate(run)
