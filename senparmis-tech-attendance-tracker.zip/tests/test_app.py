"""
Automated tests for the attendance tracker.
Runs against an isolated temporary folder so the real workbook is never touched.
"""
import io
import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_tmp = tempfile.mkdtemp(prefix="attendance_test_")
os.environ["ATTENDANCE_DATA_DIR"] = _tmp
os.environ["ATTENDANCE_TEACHER_PASSWORD"] = "teacherpass1"
os.environ["ATTENDANCE_STUDENT_PASSWORD"] = "studentpass1"

import flask_app  # noqa: E402
from openpyxl import load_workbook  # noqa: E402
import db  # noqa: E402
import excel_io  # noqa: E402
import store  # noqa: E402

app = flask_app.app


def _teacher_client():
    c = app.test_client()
    r = c.post("/login", data={"password": "teacherpass1"})
    assert r.status_code == 302
    return c


def test_auth_gate_and_roles():
    anon = app.test_client()
    assert anon.get("/").status_code == 302
    assert "/login" in anon.get("/").headers["Location"]
    assert anon.post("/api/save", json={}).status_code == 401

    stu = app.test_client()
    assert stu.post("/login", data={"password": "studentpass1"}).headers["Location"].endswith("/records")
    assert stu.get("/records").status_code == 200
    assert stu.get("/students").status_code == 302
    assert stu.get("/download").status_code == 302
    assert stu.post("/api/save", json={}).status_code == 403


def test_every_page_and_static_asset_loads():
    c = _teacher_client()
    for path in ["/", "/mark", "/mark?subject=MMW&date=2026-11-10", "/records", "/students",
                 "/scan", "/print", "/log", "/files", "/login"]:
        r = c.get(path)
        assert r.status_code == 200, path
    for asset in ["css/app.css", "css/mark.css", "css/print.css", "js/mark.js", "js/scan.js", "js/import.js"]:
        r = c.get("/static/" + asset)
        assert r.status_code == 200 and len(r.data) > 50, asset


def test_save_attendance_and_database_roundtrip():
    c = _teacher_client()
    r = c.post("/api/save", json={
        "subject": "MMW", "date": "2026-11-10", "topic": "=DangerTopic",
        "marks": [{"row": 0, "name": "Sample Student A", "code": "x"},
                  {"row": 0, "name": "Sample Student B", "code": "r"}],
        "new_students": ["Added Student"],
    })
    assert r.status_code == 200 and r.get_json()["ok"] is True
    sd = store.load_data()["MMW"]
    day = next(d for d in sd["dates"] if d["date"].isoformat() == "2026-11-10")
    assert day["topic"] == "DangerTopic"            # leading '=' stripped against formula injection
    by_name = {s["name"]: sd["cells"].get((s["row"], day["col"]), "") for s in sd["students"]}
    assert by_name["Sample Student A"] == "x" and by_name["Sample Student B"] == "r"
    assert "Added Student" in by_name
    # changing a mark updates it, and clearing removes it
    c.post("/api/save", json={"subject": "MMW", "date": "2026-11-10", "topic": "",
                              "marks": [{"name": "Sample Student A", "code": "p"},
                                        {"name": "Sample Student B", "code": "", "clear": True}]})
    sd = store.load_data()["MMW"]
    by_name = {s["name"]: sd["cells"].get((s["row"], day["col"]), "") for s in sd["students"]}
    assert by_name["Sample Student A"] == "p" and by_name["Sample Student B"] == ""
    assert c.post("/api/save", json={"subject": "Nope", "date": "2026-11-10", "marks": []}).status_code == 400


def test_excel_export_and_import_roundtrip():
    c = _teacher_client()
    r = c.get("/download")
    assert r.status_code == 200 and r.data[:2] == b"PK"
    wb = load_workbook(io.BytesIO(r.data))
    assert "MMW" in wb.sheetnames
    # import the exported workbook into a brand-new database and compare
    path = os.path.join(_tmp, "roundtrip.xlsx")
    wb.save(path)
    original = store.load_data()
    fresh = os.path.join(_tmp, "fresh.db")
    conn = db.connect(fresh)
    db.migrate(conn)
    store.import_data(conn, excel_io.read_workbook(path))
    conn.commit()
    conn.close()
    conn = db.connect(fresh)
    n_students = conn.execute("SELECT COUNT(*) FROM students").fetchone()[0]
    n_marks = conn.execute("SELECT COUNT(*) FROM attendance").fetchone()[0]
    conn.close()
    assert n_students == len({s["name"].casefold() for sd in original.values() for s in sd["students"]})
    assert n_marks == sum(len(sd["cells"]) for sd in original.values())


def test_backup_is_a_valid_database():
    store.backup_latest()
    from config import BACKUP_DIR
    conn = db.connect(os.path.join(BACKUP_DIR, "attendance_LATEST.db"))
    assert conn.execute("SELECT COUNT(*) FROM subjects").fetchone()[0] >= 1
    conn.close()


def test_students_subjects_and_meet_import():
    c = _teacher_client()
    assert c.post("/students/add", data={"names": "Maria Santos", "subjects": ["MMW"]}).status_code == 302
    assert c.post("/subjects/add", data={"name": "Physics", "copy_from": "MMW"}).status_code == 302
    csv_bytes = ("Created on 2026-11-08 09:00:00\nEnded on 2026-11-08 10:00:00\n\n"
                 "Full Name,Time in Call\nMaria Santos,50:00\n").encode()
    r = c.post("/import", data={"subject": "MMW", "csv": (io.BytesIO(csv_bytes), "m.csv")},
               content_type="multipart/form-data")
    assert r.status_code == 200 and b"Maria Santos" in r.data
    assert c.post("/dates/delete", data={"subject": "MMW", "date": "2026-11-10"}).status_code == 302
    assert c.post("/subjects/delete", data={"subject": "Physics"}).status_code == 302


def test_cross_origin_post_blocked():
    c = _teacher_client()
    r = c.post("/api/save", json={}, headers={"Origin": "https://evil.example"})
    assert r.status_code == 403


def test_dark_mode_toggle_and_css_present():
    c = _teacher_client()
    html = c.get("/").get_data(as_text=True)
    assert 'id="themeToggleBtn"' in html
    assert "data-theme" in html
    css = c.get("/static/css/app.css").get_data(as_text=True)
    assert '[data-theme="dark"]' in css


def test_student_lookup():
    c = _teacher_client()
    r = c.get("/lookup?q=sample student a")
    assert r.status_code == 200
    assert b"Sample Student A" in r.data
    assert b"Print slip" in r.data
    assert b"No student matches" in c.get("/lookup?q=zzzz").data
    stu = app.test_client()
    stu.post("/login", data={"password": "studentpass1"})
    assert stu.get("/lookup").status_code == 302


def test_per_teacher_accounts_and_subject_isolation():
    admin = _teacher_client()
    assert admin.get("/teachers").status_code == 200
    r = admin.post("/teachers/add", data={
        "username": "msantos", "display_name": "Prof. Santos", "password": "santospassword1",
    })
    assert r.status_code == 302
    teachers = store.list_teachers()
    santos = next(t for t in teachers if t["username"] == "msantos")
    assert not santos["is_admin"]

    # Assign MMW to Prof. Santos; College Algebra remains unassigned (admin-only when signed in as non-admin)
    assert admin.post("/teachers/assign_subject",
                      data={"subject": "MMW", "teacher_id": str(santos["id"])}).status_code == 302

    # Sign in as Prof. Santos
    tc = app.test_client()
    r = tc.post("/login", data={"username": "msantos", "password": "santospassword1"})
    assert r.status_code == 302 and r.headers["Location"].endswith("/")
    dash = tc.get("/").get_data(as_text=True)
    assert "MMW" in dash
    assert "College Algebra" not in dash

    # Non-admin teacher cannot modify an unassigned / other teacher's subject
    r_forbid = tc.post("/api/save", json={
        "subject": "College Algebra", "date": "2026-11-11", "topic": "Forbidden",
        "marks": [{"name": "Sample Student A", "code": "p"}],
    })
    assert r_forbid.status_code == 400

    # Non-admin teacher can create their own subject and it is automatically owned by them
    assert tc.post("/subjects/add", data={"name": "Data Structures", "copy_from": "MMW"}).status_code == 302
    assert "Data Structures" in tc.get("/").get_data(as_text=True)

    # Non-admin cannot create another teacher account
    tc.post("/teachers/add", data={"username": "hacker", "password": "hackerpassword1"})
    assert not any(t["username"] == "hacker" for t in store.list_teachers())

    # Clean up test subject and teacher
    assert admin.post("/subjects/delete", data={"subject": "Data Structures"}).status_code == 302
    assert admin.post("/teachers/delete", data={"teacher_id": str(santos["id"])}).status_code == 302


def test_sections_management_and_lookup_filter():
    c = _teacher_client()
    data = store.load_data()
    assert data["MMW"]["section"] == "BSCS-1A"

    # Add a second section BSCS-1B to MMW
    r = c.post("/sections/add", data={"subject": "MMW", "section": "BSCS-1B", "copy_from_section": ""})
    assert r.status_code == 302
    assert c.post("/students/add", data={"names": "Juan Dela Cruz", "subjects": ["MMW"], "section": "BSCS-1B"}).status_code == 302

    # Mark attendance in BSCS-1B and ensure BSCS-1A is unaffected
    r = c.post("/api/save", json={
        "subject": "MMW", "section": "BSCS-1B", "date": "2026-11-12", "topic": "Pointers",
        "marks": [{"name": "Juan Dela Cruz", "code": "p"}],
    })
    assert r.status_code == 200 and r.get_json()["ok"] is True

    # Lookup by section BSCS-1B finds Juan Dela Cruz
    lk = c.get("/lookup?section=BSCS-1B").get_data(as_text=True)
    assert "Juan Dela Cruz" in lk
    assert "BSCS-1B" in lk

    # Rename BSCS-1B -> BSCS-1C and then delete it
    assert c.post("/sections/rename", data={"subject": "MMW", "old_section": "BSCS-1B", "new_section": "BSCS-1C"}).status_code == 302
    assert "BSCS-1C" in store.load_data()["MMW"]["section_names"]
    assert c.post("/sections/delete", data={"subject": "MMW", "section": "BSCS-1C"}).status_code == 302
    assert "BSCS-1C" not in store.load_data()["MMW"]["section_names"]


def test_delete_subject_and_restore_from_log():
    c = _teacher_client()
    assert c.post("/subjects/add", data={"name": "RestoreMe"}).status_code == 302
    assert "RestoreMe" in store.load_data()

    # Delete the subject (creates a before_delete_subject snapshot)
    assert c.post("/subjects/delete", data={"subject": "RestoreMe"}).status_code == 302
    assert "RestoreMe" not in store.load_data()

    backups = store.list_backups()
    snap = next(b for b in backups if "RestoreMe" in b["subjects"])
    assert c.post("/backups/restore", data={"filename": snap["filename"]}).status_code == 302
    assert "RestoreMe" in store.load_data()

    # Clean up
    c.post("/subjects/delete", data={"subject": "RestoreMe"})


def test_student_profile_and_guardian_contact():
    c = _teacher_client()
    r = c.post("/students/profile", data={
        "old_name": "Sample Student A",
        "name": "Sample Student A",
        "student_no": "2026-00101",
        "guardian_name": "Elena Santos",
        "guardian_phone": "0917-555-0199",
        "email": "student.a@school.edu",
        "address": "123 Rizal St, Quezon City",
        "subject": "MMW",
        "next": "lookup",
    })
    assert r.status_code == 302
    lk = c.get("/lookup?q=2026-00101").get_data(as_text=True)
    assert "Sample Student A" in lk
    assert "Elena Santos" in lk
    assert "0917-555-0199" in lk
    assert "123 Rizal St, Quezon City" in lk


def test_grades_weights_lock_and_scale():
    c = _teacher_client()
    assert c.get("/grades?subject=MMW").status_code == 200

    # Change weights to 40 / 40 / 20 and lock them
    assert c.post("/grades/weights", data={
        "subject": "MMW", "section": "BSCS-1A",
        "exam_weight": "40", "quiz_weight": "40", "activity_weight": "20",
    }).status_code == 302
    assert c.post("/grades/lock", data={"subject": "MMW", "section": "BSCS-1A", "locked": "1"}).status_code == 302
    gb = store.load_grades("MMW", "BSCS-1A")
    assert gb["locked"] is True and gb["weights"]["exam"] == 40.0

    # Attempting to change weights while locked does not alter them
    c.post("/grades/weights", data={
        "subject": "MMW", "section": "BSCS-1A",
        "exam_weight": "60", "quiz_weight": "20", "activity_weight": "20",
    })
    assert store.load_grades("MMW", "BSCS-1A")["weights"]["exam"] == 40.0

    # Add Exam, Quiz, and Activity items
    c.post("/grades/items/add", data={"subject": "MMW", "section": "BSCS-1A", "category": "exam", "title": "Midterm", "max_score": "100"})
    c.post("/grades/items/add", data={"subject": "MMW", "section": "BSCS-1A", "category": "quiz", "title": "Quiz 1", "max_score": "50"})
    c.post("/grades/items/add", data={"subject": "MMW", "section": "BSCS-1A", "category": "activity", "title": "Lab 1", "max_score": "20"})

    gb = store.load_grades("MMW", "BSCS-1A")
    stu_a = next(r for r in gb["rows"] if r["name"] == "Sample Student A")
    eid = stu_a["enrollment_id"]
    items = {it["title"]: it["id"] for it in gb["items"]}

    # Enter scores for Sample Student A: 95/100 exam (95%), 45/50 quiz (90%), 20/20 activity (100%)
    # Weighted: 95*0.4 + 90*0.4 + 100*0.2 = 38 + 36 + 20 = 94.0% -> 1.25
    form_data = {
        "subject": "MMW", "section": "BSCS-1A",
        f"score_{eid}_{items['Midterm']}": "95",
        f"score_{eid}_{items['Quiz 1']}": "45",
        f"score_{eid}_{items['Lab 1']}": "20",
    }
    assert c.post("/grades/scores", data=form_data).status_code == 302
    gb2 = store.load_grades("MMW", "BSCS-1A")
    stu_a2 = next(r for r in gb2["rows"] if r["name"] == "Sample Student A")
    assert round(stu_a2["final_pct"], 1) == 94.0
    assert stu_a2["scale"] == "1.25"

    # Student Lookup displays the computed grade standing and breakdown
    lk = c.get("/lookup?student=Sample+Student+A").get_data(as_text=True)
    assert "94.0% (1.25)" in lk
    assert "Midterm" in lk


def test_archive_and_unarchive_subject():
    c = _teacher_client()
    # Add a dedicated test subject
    c.post("/subjects/add", data={"name": "Test History 101"})
    assert "Test History 101" in [s["name"] for s in store.list_subjects_with_owners()]
    assert not store.is_subject_archived("Test History 101")

    # Archive the subject
    res = c.post("/subjects/archive", data={"subject": "Test History 101", "note": "Finished semester"})
    assert res.status_code == 302
    assert store.is_subject_archived("Test History 101")

    # It must not show up in active dashboard or load_data
    assert "Test History 101" not in store.load_data()
    assert "Test History 101" in store.load_data(include_archived=True)

    # Navigating to mark should redirect with warning
    mark_res = c.get("/mark?subject=Test+History+101")
    assert mark_res.status_code == 302
    assert "/records" in mark_res.headers["Location"]

    # Records and Gradebook remain accessible and display ARCHIVED SUBJECT
    rec_html = c.get("/records?subject=Test+History+101").get_data(as_text=True)
    assert "ARCHIVED SUBJECT" in rec_html

    gb_html = c.get("/grades?subject=Test+History+101").get_data(as_text=True)
    assert "ARCHIVED SUBJECT" in gb_html

    # Students page shows it under Archived Subjects
    stu_html = c.get("/students").get_data(as_text=True)
    assert "Archived Subjects (Preserved Records)" in stu_html
    assert "Test History 101" in stu_html

    # Restore the subject
    unres = c.post("/subjects/unarchive", data={"subject": "Test History 101"})
    assert unres.status_code == 302
    assert not store.is_subject_archived("Test History 101")

    # Clean up
    c.post("/subjects/delete", data={"subject": "Test History 101"})


def test_mobile_rest_api_endpoints():
    client = app.test_client()

    # 1. Unauthenticated requests to API endpoints return 401
    assert client.get("/api/me").status_code == 401
    assert client.get("/api/dashboard").status_code == 401
    assert client.get("/api/subjects").status_code == 401

    # 2. Login via /api/login with invalid password
    bad_login = client.post("/api/login", json={"password": "wrongpassword"})
    assert bad_login.status_code == 401
    assert not bad_login.get_json()["ok"]

    # 3. Login via /api/login with valid teacher password
    good_login = client.post("/api/login", json={"password": "teacherpass1"})
    assert good_login.status_code == 200
    login_data = good_login.get_json()
    assert login_data["ok"]
    assert login_data["role"] == "teacher"

    # 4. /api/me returns active session
    me = client.get("/api/me").get_json()
    assert me["ok"]
    assert me["authenticated"]
    assert me["role"] == "teacher"

    # 5. /api/dashboard returns academic overview stats & cards
    dash = client.get("/api/dashboard").get_json()
    assert dash["ok"]
    assert "overview" in dash
    assert dash["overview"]["total_students"] > 0
    assert len(dash["cards"]) > 0

    # 6. /api/subjects returns active and archived subjects
    subs = client.get("/api/subjects").get_json()
    assert subs["ok"]
    assert len(subs["subjects"]) > 0
    sub_name = subs["subjects"][0]["name"]
    sec_name = subs["subjects"][0]["sections"][0]

    # 7. /api/mark returns roster and attendance state
    mark_data = client.get(f"/api/mark?subject={sub_name}&section={sec_name}").get_json()
    assert mark_data["ok"]
    assert mark_data["subject"] == sub_name
    assert len(mark_data["students"]) > 0

    # 8. /api/records returns attendance matrix
    rec_data = client.get(f"/api/records?subject={sub_name}&section={sec_name}").get_json()
    assert rec_data["ok"]
    assert "rows" in rec_data

    # 9. /api/grades returns gradebook items and rows
    grade_data = client.get(f"/api/grades?subject={sub_name}&section={sec_name}").get_json()
    assert grade_data["ok"]
    assert "weights" in grade_data

    # 10. /api/lookup returns matching students
    lookup_data = client.get("/api/lookup?q=Sample").get_json()
    assert lookup_data["ok"]
    assert lookup_data["total_matches"] > 0

    # 11. /api/logout terminates the session
    logout_res = client.post("/api/logout")
    assert logout_res.status_code == 200
    assert client.get("/api/me").status_code == 401







